import Foundation
import AVFoundation
import AppKit
let out = CommandLine.arguments[1]
let files = Array(CommandLine.arguments.dropFirst(2))
var videos: [[String: Any]] = []
for (i, path) in files.enumerated() {
 let id = i == 0 ? "01-lobby-to-elevator" : "02-elevator-floor4-lounge-offices"
 let asset = AVURLAsset(url: URL(fileURLWithPath: path))
 let duration = CMTimeGetSeconds(asset.duration)
 let gen = AVAssetImageGenerator(asset: asset)
 gen.appliesPreferredTrackTransform = true
 gen.maximumSize = CGSize(width: 1920, height: 1920)
 gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero
 let dir = "\(out)/reference/frames/\(id)"
 try FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true)
 var frames: [[String: Any]] = []
 for sec in stride(from: 0.0, to: duration, by: 0.5) {
  var actual = CMTime.zero
  let cg = try gen.copyCGImage(at: CMTime(seconds: sec, preferredTimescale: 600), actualTime: &actual)
  let filename = String(format:"frame-%06dms.jpg", Int(sec * 1000))
  let data = NSBitmapImageRep(cgImage: cg).representation(using: .jpeg, properties: [.compressionFactor: 0.9])!
  try data.write(to: URL(fileURLWithPath:"\(dir)/\(filename)"))
  frames.append(["requestedSeconds":sec,"actualSeconds":CMTimeGetSeconds(actual),"width":cg.width,"height":cg.height,"path":"frames/\(id)/\(filename)"])
 }
 videos.append(["id":id,"originalFile":URL(fileURLWithPath:path).lastPathComponent,"durationSeconds":duration,"intervalSeconds":0.5,"frames":frames])
 print("\(id): \(duration)s, \(frames.count) frames")
 let sheetDir="\(out)/reference/contact-sheets/\(id)"
 try FileManager.default.createDirectory(atPath:sheetDir,withIntermediateDirectories:true)
 for start in stride(from:0,to:frames.count,by:12) {
  let group=Array(frames[start..<min(start+12,frames.count)])
  let size=NSSize(width:960,height:Double((group.count+3)/4)*445)
  let sheet=NSImage(size:size); sheet.lockFocus(); NSColor(calibratedWhite:0.94,alpha:1).setFill(); NSRect(origin:.zero,size:size).fill()
  for (j,f) in group.enumerated() {
   let relative=f["path"] as! String
   let img=NSImage(contentsOfFile:"\(out)/reference/\(relative)")!
   let x=Double(j%4)*240, y=size.height-Double(j/4+1)*445
   let scale=min(232/img.size.width,410/img.size.height), w=img.size.width*scale,h=img.size.height*scale
   img.draw(in:NSRect(x:x+(240-w)/2,y:y+30+(410-h)/2,width:w,height:h))
   let label=String(format:"%02d:%04.1f",Int((f["requestedSeconds"] as! Double)/60),(f["requestedSeconds"] as! Double).truncatingRemainder(dividingBy:60))
   (label as NSString).draw(at:NSPoint(x:x+12,y:y+6),withAttributes:[.font:NSFont.monospacedSystemFont(ofSize:17,weight:.medium),.foregroundColor:NSColor.black])
  }
  sheet.unlockFocus()
  let rep=NSBitmapImageRep(data:sheet.tiffRepresentation!)!
  try rep.representation(using:.jpeg,properties:[.compressionFactor:0.88])!.write(to:URL(fileURLWithPath:String(format:"%@/sheet-%03d.jpg",sheetDir,start/12+1)))
 }
}
let metadata:[String:Any] = ["intervalSeconds":0.5,"maxDimension":1920,"orientationCorrected":true,"videos":videos]
try JSONSerialization.data(withJSONObject:metadata,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:"\(out)/reference/frames.json"))
