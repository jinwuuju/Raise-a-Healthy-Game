import { expect, test, type Page } from '@playwright/test';
type Hook = { world: { roomId: string; tap(p: {x: number;y: number}): void }; game: {state: object; importState(s: object): void} };
const room = (p: Page) => p.evaluate(() => (window as unknown as {__mq: Hook}).__mq.world.roomId);
async function tap(p: Page, x: number, y: number) { await p.evaluate(([x,y]) => (window as unknown as {__mq: Hook}).__mq.world.tap({x:x!,y:y!}), [x,y]); }
async function seed(p: Page, id: string, x: number, y: number) {
 await p.evaluate(({id,x,y}) => { const h=(window as unknown as {__mq: Hook}).__mq; h.game.importState({...h.game.state,at:{room:id,x,y,facing:'up'}}); },{id,x,y});
 await p.reload();
 await expect.poll(()=>room(p)).toBe(id); await p.waitForTimeout(400);
}
for (const [width,height] of [[1280,900],[390,844],[844,390]]) test(`Euro Plaza upstairs and back ${width}x${height}`, async ({page}) => {
 test.setTimeout(120000); await page.setViewportSize({width:width!,height:height!});
 const errors:string[]=[]; page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/'); await page.getByRole('button',{name:'첫 출근하기'}).click();
 await seed(page,'lobby',256,324);
 await page.screenshot({path:`artifacts/euro-lobby-${width}.png`});
 await tap(page,5,96); await expect.poll(()=>room(page),{timeout:15000}).toBe('lift1'); await page.waitForTimeout(400);
 await tap(page,132,84); await expect(page.locator('.dialog')).toBeVisible({timeout:8000}); await page.keyboard.press('e');
 await page.getByRole('button',{name:/4층 · 라운지/}).click(); await expect.poll(()=>room(page)).toBe('lift4'); await page.waitForTimeout(400);
 await page.reload(); await expect.poll(()=>room(page)).toBe('lift4'); await page.waitForTimeout(400);
 await tap(page,80,155); await expect.poll(()=>room(page)).toBe('floor4'); await page.waitForTimeout(400);
 await page.screenshot({path:`artifacts/euro-floor4-${width}.png`});
 await tap(page,208,192);
 await expect.poll(() => page.evaluate(() => {
   const w=(window as unknown as {__mq: Hook & {world: {player: {x:number;y:number}}}}).__mq.world;
   return w.player.x < 240 && w.player.y < 224;
 }), {timeout:12000}).toBe(true);
 expect(await room(page)).toBe('floor4'); // No door, fade or room swap at the open office boundary.
 await tap(page,288,240); await page.waitForTimeout(2200);
 await tap(page,244,336); await expect.poll(()=>room(page),{timeout:12000}).toBe('lounge'); await page.waitForTimeout(400);
 await page.screenshot({path:`artifacts/euro-lounge-${width}.png`});
 await tap(page,380,176); await expect.poll(()=>room(page)).toBe('floor4'); await page.waitForTimeout(400);
 await tap(page,288,52); await expect.poll(()=>room(page),{timeout:10000}).toBe('newsroom'); await page.waitForTimeout(400);
 await page.screenshot({path:`artifacts/euro-inner-${width}.png`});
 await tap(page,336,378); await expect.poll(()=>room(page),{timeout:12000}).toBe('floor4'); await page.waitForTimeout(400);
 await tap(page,288,443); await expect.poll(()=>room(page),{timeout:15000}).toBe('lift4');
 expect(errors).toEqual([]);
});

test('render full room plans from the actual game assets', async ({page}) => {
 await page.goto('/');
 const images = await page.evaluate(async () => {
  const roomPath='/src/world/rooms.ts', groundPath='/src/art/ground.ts', propsPath='/src/art/props.ts';
  const {rooms}=await import(roomPath), {bakeGround}=await import(groundPath), {propSprite}=await import(propsPath);
  const characterPath='/src/art/character.ts', avatarPath='/src/art/avatar.ts';
  const {characterFrame}=await import(characterPath), {AX,AY}=await import(avatarPath);
  const result: Record<string,string>={};
  for (const id of ['lobby','floor4','lounge','newsroom']) {
   const r=rooms[id], c=document.createElement('canvas'); c.width=r.cols*32;c.height=r.rows*32;
   const g=c.getContext('2d')!;g.imageSmoothingEnabled=false;g.scale(2,2);g.drawImage(bakeGround(r),0,0);
   const actors=[...r.props.map((p: {kind:string;v:number;x:number;y:number})=>({y:p.y,draw:()=>{const s=propSprite(p.kind,p.v);g.drawImage(s.c,p.x-s.ax,p.y-s.ay);}})), ...r.npcs.map((n: {look:unknown;facing:string;x:number;y:number})=>({y:n.y,draw:()=>g.drawImage(characterFrame(n.look,n.facing,0),n.x-AX,n.y-AY)}))];
   for(const a of actors.sort((a,b)=>a.y-b.y))a.draw();
   result[id]=c.toDataURL('image/png').split(',')[1]!;
  } return result;
 });
 const {writeFileSync}=await import('node:fs');
 for(const [id,png] of Object.entries(images))writeFileSync(`artifacts/euro-plan-${id}.png`,Buffer.from(png,'base64'));
 expect(Object.keys(images)).toHaveLength(4);
});
