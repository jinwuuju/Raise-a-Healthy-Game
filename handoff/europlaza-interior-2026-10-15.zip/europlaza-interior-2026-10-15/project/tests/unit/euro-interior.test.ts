import { describe, expect, it } from 'vitest';
import { rooms } from '../../src/world/rooms';
import { canStand } from '../../src/world/collision';
import { findPath } from '../../src/world/path';
import { newState, validateState } from '../../src/domain/state';
import { wasLegacyLobbyPosition } from '../../src/world/legacy-lobby';

describe('D093 continuous Euro Plaza route', () => {
  it('uses a wider inner office and the sketch left-side lift recess', () => {
    expect(rooms.newsroom.cols).toBeGreaterThan(rooms.newsroom.rows);
    expect(rooms.lobby.doors[0]?.zone.x).toBe(0);
    expect(canStand('lobby', { x: 136, y: 130 })).toBe(false);
    expect(canStand('lobby', { x: 136, y: 200 })).toBe(true);
  });
  it('routes both ways through the cabin, landing and corridor instead of directly to the office', () => {
    expect(rooms.lobby.doors.find(d => d.id === 'elevator')?.to).toBe('lift1');
    expect(rooms.lift1.doors[0]?.to).toBe('lobby');
    expect(rooms.lift4.doors[0]?.to).toBe('floor4');
    expect(rooms.floor4.doors.map(d => d.to)).toEqual(['lift4', 'lounge', 'newsroom']);
    expect(rooms.newsroom.doors[0]?.to).toBe('floor4');
    expect(rooms.lounge.doors[0]?.to).toBe('floor4');
  });
  it('keeps closed glazing solid and the entrance and lounge openings walkable', () => {
    for (const p of [{ x: 104, y: 406 }, { x: 248, y: 288 }, { x: 264, y: 392 }, { x: 320, y: 392 }]) expect(canStand('floor4', p)).toBe(false);
    for (const p of [{ x: 288, y: 392 }, { x: 248, y: 336 }]) expect(canStand('floor4', p)).toBe(true);
    expect(canStand('floor4', { x: 110, y: 332 })).toBe(false);
    expect(rooms.floor4.props.some(p => p.kind === 'longtable' || p.kind === 'pantry')).toBe(false);
    expect(findPath('floor4', { x: 288, y: 176 }, { x: 208, y: 176 }).length).toBeGreaterThan(0);
    expect(rooms.floor4.doors.some(d => d.to === 'outeroffice')).toBe(false);
  });
  it('keeps a saved cabin floor and all existing progress on reload', () => {
    for (const room of ['lift1', 'lift4', 'floor4', 'lounge'] as const) {
      const base = newState();
      const s = validateState({ ...base, at: { room, ...rooms[room].spawn, facing: 'up' } });
      expect(s.at.room).toBe(room); expect(s.gold).toBe(base.gold); expect(s.ledger).toEqual(base.ledger);
    }
  });
  it('migrates the removed outer office and hidden lounge without changing progress', () => {
    const base = newState();
    for (const [room, x, y, expected] of [['outeroffice', 348, 176, 'floor4'], ['floor4', 200, 336, 'lounge'], ['newsroom', 120, 240, 'newsroom']] as const) {
      const result = validateState({ ...base, at: { room, x, y, facing: 'up' } });
      expect(result.at.room).toBe(expected); expect(canStand(result.at.room, result.at)).toBe(true);
      expect(result.article).toEqual(base.article); expect(result.ledger).toEqual(base.ledger);
    }
    expect(() => validateState({ ...base, at: { room: 'outeroffice', x: 0, y: 0, facing: 'up' } })).toThrow();
  });
  it('relocates only formerly valid lobby positions covered by new furniture', () => {
    const base = newState(), p = { x: 136, y: 130 };
    expect(wasLegacyLobbyPosition(p)).toBe(true); expect(canStand('lobby', p)).toBe(false);
    const s = validateState({ ...base, at: { room: 'lobby', ...p, facing: 'down' } });
    expect(s.at).toEqual({ room: 'lobby', ...rooms.lobby.spawn, facing: 'up' });
    expect(s.article).toEqual(base.article); expect(s.lunch).toEqual(base.lunch);
    for (const p of [{ x: -1, y: 100 }, { x: 72, y: 100 }, { x: Infinity, y: 80 }]) expect(wasLegacyLobbyPosition(p)).toBe(false);
  });
});
