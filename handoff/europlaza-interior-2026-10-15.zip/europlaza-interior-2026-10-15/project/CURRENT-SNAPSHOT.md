# 작업 시작점

기준 main 커밋: `37640afbe9e8326107b606d238d7d17eef835b3c`. 이 폴더는 그 커밋에 로컬 실내 작업 D092/D093을 반영한 **현재 파일 전체 스냅샷**이다. 아직 main에 커밋·배포되지 않은 파일도 포함한다. main만 clone해서는 현재 구현이 보이지 않는다. 별도 폴더에서 비교·실행한 뒤 필요한 변경만 기존 저장소에 통합하고 사용자의 다른 작업을 덮어쓰지 않는다. `.git`, node_modules, dist, data/raw, 별도 작업인 tools/district와 DISTRICT-1KM 문서는 포함하지 않았다.

Node 24.19.x / npm 12.2.x. `npm ci`, `npm run dev`. 이 Mac에서는 `bash tools/npm-local.sh run dev`도 가능하다. 게임 그림은 src/art의 코드로 생성하며 Phaser를 쓰지 않는다.
