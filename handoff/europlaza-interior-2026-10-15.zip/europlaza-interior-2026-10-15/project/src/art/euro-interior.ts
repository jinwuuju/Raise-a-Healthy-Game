/** Video-derived materials and furniture (D092). No photographed people, logos or screen contents. */
import { rect, ellipse, px, sprite, hash2, type Ctx, type Sprite } from './pixel';
import { T, tileAt, type Room } from '../world/rooms';
const ink = '#4c5255';
export function euroProp(kind: string, v = 0): Sprite | null {
  if (kind === 'benchdesk' || kind === 'shortbench' || kind === 'editorbench') {
    const w = kind === 'shortbench' ? 76 : 140, facing = kind !== 'editorbench';
    const seats = w < 100 ? [22, 54] : [22, 70, 118];
    return sprite(w, 72, w / 2, 71, g => {
      rect(g, 4, 58, 3, 13, '#b4bdb9'); rect(g, w - 7, 58, 3, 13, '#b4bdb9');
      rect(g, 0, facing ? 24 : 34, w, facing ? 35 : 25, '#f2f1e9');
      rect(g, 0, facing ? 24 : 34, w, 2, '#ffffff'); rect(g, 0, 59, w, 3, '#bac1b9');
      if (facing) rect(g, 1, 40, w - 2, 1, '#b8bfba'); // Two joined desks share one central seam.
      for (const x of seats) {
        if (facing) {
          rect(g, x - 10, 9, 20, 13, '#4c5759'); rect(g, x - 8, 11, 16, 9, '#6f7c7a');
          rect(g, x - 1, 22, 2, 5, '#919c98'); rect(g, x - 6, 27, 12, 1, '#87938e');
          rect(g, x - 9, 30, 18, 2, '#b4beb7');
        }
        rect(g, x - 10, 34, 20, 13, '#35474d'); rect(g, x - 8, 36, 16, 9, '#71969a');
        rect(g, x - 7, 37, 11, 1, '#bad0ca'); rect(g, x - 1, 47, 2, 4, '#8d9b96');
        rect(g, x - 6, 51, 12, 1, '#8d9b96'); rect(g, x - 9, 55, 18, 2, '#bec8c0');
      }
    }, ink);
  }
  if (kind === 'lobbytable') return sprite(76, 44, 38, 43, g => {
    rect(g, 35, 21, 6, 17, '#d6c4a5'); ellipse(g, 38, 40, 13, 3, '#c9b697');
    ellipse(g, 38, 16, 36, 13, '#dacdb4'); ellipse(g, 38, 13, 36, 12, '#fff6df');
    rect(g, 27, 8, 15, 7, '#e8dec7'); rect(g, 29, 10, 10, 1, '#bf9e70');
  }, '#807567');
  if (kind === 'lobbysofa') return sprite(58, 32, 29, 31, g => {
    // Back along the top, seat opens toward the bottom entrance.
    rect(g, 4, 2, 50, 12, '#aba08a'); rect(g, 5, 3, 48, 2, '#d3c5ab');
    rect(g, 1, 9, 7, 16, '#978b75'); rect(g, 50, 9, 7, 16, '#978b75');
    rect(g, 8, 15, 42, 8, '#c7b99e'); rect(g, 28, 15, 1, 8, '#a89980');
    rect(g, 5, 24, 48, 4, '#8e806c'); rect(g, 5, 28, 3, 3, '#b58c52'); rect(g, 50, 28, 3, 3, '#b58c52');
  }, '#6c6458');
  if (kind === 'lobbyplant') return sprite(42, 68, 21, 67, g => {
    ellipse(g, 21, 64, 13, 3, '#aa8b59'); rect(g, 9, 46, 24, 17, '#ded0ac'); rect(g, 9, 46, 3, 16, '#f9ebc7');
    rect(g, 29, 48, 4, 15, '#bdab85'); ellipse(g, 21, 46, 13, 4, '#f3e4bf'); ellipse(g, 21, 46, 10, 2, '#8f7850');
    for (const dx of [-9, -4, 2, 8]) rect(g, 20 + dx, 17, 1, 29, '#7b8350');
    for (const [x,y,rx,ry] of [[21,9,6,8],[10,18,8,5],[31,18,8,5],[6,30,6,4],[35,30,6,4],[14,31,8,6],[27,30,8,6],[21,21,6,9]]) {
      ellipse(g,x!,y!,rx!,ry!,'#7c9252'); ellipse(g,x!-1,y!-2,rx!-1,ry!-1,'#acb96d'); px(g,x!-2,y!-3,'#d3d591');
    }
  }, '#646b43');
  if (kind === 'reception-side') return sprite(28, 96, 14, 95, g => {
    rect(g, 3, 4, 22, 89, '#c5c7bd'); rect(g, 3, 4, 22, 76, '#f1efe5');
    rect(g, 3, 4, 2, 76, '#ffffff'); rect(g, 23, 5, 2, 88, '#9eaaa4');
    rect(g, 5, 81, 18, 1, '#aeb7b0'); rect(g, 6, 20, 11, 15, '#444e52'); rect(g, 7, 22, 8, 11, '#6c9298');
    rect(g, 9, 52, 10, 7, '#ffffff'); rect(g, 10, 54, 7, 1, '#b5bfbc');
  }, ink);
  if (kind === 'sofa-side') return sprite(24, 60, 12, 59, g => {
    rect(g, 2, 2, 7, 51, '#929c98'); rect(g, 3, 3, 3, 48, '#c0c6c0');
    rect(g, 9, 6, 12, 44, '#b6bfb9'); rect(g, 9, 27, 12, 1, '#929c98');
    rect(g, 7, 2, 16, 5, '#a3ada8'); rect(g, 7, 49, 16, 5, '#a3ada8');
    rect(g, 6, 54, 3, 4, '#b09263'); rect(g, 19, 54, 3, 4, '#b09263');
  }, ink);
  if (kind === 'eurodesk' || kind === 'euroeditor') {
    const w = kind === 'euroeditor' ? 68 : 52;
    return sprite(w, 34, w / 2, 33, g => {
      rect(g, 3, 24, 3, 9, '#c6cac8'); rect(g, w - 6, 24, 3, 9, '#c6cac8');
      rect(g, 0, 16, w, 9, '#e7e8e0'); rect(g, 1, 16, w - 2, 2, '#ffffff'); rect(g, 0, 25, w, 2, '#b7bbb5');
      rect(g, 17, 1, 22, 14, '#343c40'); rect(g, 19, 3, 18, 10, '#52616a'); rect(g, 20, 4, 12, 1, '#8097a0');
      rect(g, 27, 15, 2, 4, '#626b6f'); rect(g, 23, 19, 10, 1, '#697477');
      rect(g, 17, 21, 19, 2, '#a8afaf'); rect(g, 5, 19, 8, 4, '#fafbf6'); px(g, 7, 20, '#acb5b2');
      rect(g, w - 9, 14, 4, 6, '#b1bfbc'); rect(g, w - 9, 14, 4, 1, '#e4eeeb');
    }, ink);
  }
  if (kind === 'officechair' && v === 1) return sprite(18, 25, 9, 24, g => {
    rect(g, 3, 4, 12, 7, '#cbd2cc'); rect(g, 1, 5, 3, 7, '#8e9b95'); rect(g, 14, 5, 3, 7, '#8e9b95');
    rect(g, 3, 12, 12, 8, '#949f9a'); rect(g, 4, 13, 10, 6, '#b5c0b8');
    rect(g, 8, 20, 2, 3, '#84918a'); rect(g, 3, 23, 12, 1, '#b7c3bb'); px(g, 2, 24, ink); px(g, 14, 24, ink);
  }, ink);
  if (kind === 'officechair') return sprite(18, 25, 9, 24, g => {
    rect(g, 3, 1, 12, 11, '#a3aaa9'); rect(g, 4, 2, 10, 8, '#d0d4d0');
    for (let y = 3; y < 10; y += 2) rect(g, 5, y, 8, 1, '#b2bbb6');
    rect(g, 2, 13, 14, 4, '#c7ceca'); rect(g, 0, 11, 3, 5, '#858e8c'); rect(g, 15, 11, 3, 5, '#858e8c');
    rect(g, 8, 17, 2, 5, '#929b99'); rect(g, 3, 22, 12, 1, '#bcc2c0'); px(g, 2, 23, ink); px(g, 14, 23, ink); px(g, 8, 24, ink);
  }, ink);
  if (kind === 'cabinet') return sprite(50, 30, 25, 29, g => {
    rect(g, 1, 1, 48, 27, '#e7e9e4'); rect(g, 1, 1, 48, 3, '#ffffff'); rect(g, 25, 5, 1, 22, '#bcc2be');
    rect(g, 21, 10, 1, 6, '#909a96'); rect(g, 29, 10, 1, 6, '#909a96'); rect(g, 2, 28, 46, 1, '#a1aaa5');
  }, ink);
  if (kind === 'greysofa') return sprite(52, 28, 26, 27, g => {
    rect(g, 3, 2, 46, 13, '#a3aaa8'); rect(g, 4, 3, 44, 2, '#c1c7c2');
    rect(g, 1, 9, 7, 15, '#838d8c'); rect(g, 44, 9, 7, 15, '#838d8c');
    rect(g, 8, 15, 36, 7, '#b4bcb8'); rect(g, 25, 15, 1, 7, '#929c97');
    rect(g, 4, 24, 3, 3, '#a98a60'); rect(g, 45, 24, 3, 3, '#a98a60');
  }, ink);
  if (kind === 'whitetable') return sprite(40, 24, 20, 23, g => {
    rect(g, 18, 11, 4, 9, '#c8cec9'); ellipse(g, 20, 21, 8, 2, '#bfc7c3');
    ellipse(g, 20, 9, 19, 7, '#cbd0cb'); ellipse(g, 20, 7, 19, 6, '#fafbf6');
    rect(g, 11, 5, 9, 4, '#d1dedb'); rect(g, 13, 6, 5, 1, '#759fa5');
  }, ink);
  if (kind === 'longtable') return sprite(92, 42, 46, 41, g => {
    for (const x of [4, 86]) { rect(g, x, 23, 2, 18, '#404849'); rect(g, x - 2, 40, 6, 1, '#404849'); }
    rect(g, 6, 35, 80, 2, '#404849'); rect(g, 0, 5, 92, 24, '#d6ae70'); rect(g, 0, 5, 92, 2, '#f0d09a'); rect(g, 0, 29, 92, 3, '#a77e4c');
    for (let y = 10; y < 28; y += 5) rect(g, 2, y, 88, 1, '#cba36a');
    rect(g, 40, 17, 12, 2, '#8c724d');
  }, ink);
  if (kind === 'tallchair') return sprite(14, 25, 7, 24, g => {
    rect(g, 1, 1, 12, 3, '#dfc395'); rect(g, 2, 3, 2, 10, '#bc9b69'); rect(g, 10, 3, 2, 10, '#bc9b69');
    rect(g, 1, 12, 12, 3, '#e3c99c'); rect(g, 2, 15, 2, 9, '#bc9b69'); rect(g, 10, 15, 2, 9, '#bc9b69'); rect(g, 3, 21, 8, 1, '#ac8b59');
  }, '#756954');
  if (kind === 'pantry') return sprite(92, 40, 46, 39, g => {
    rect(g, 0, 18, 92, 20, '#858d8c'); rect(g, 0, 17, 92, 3, '#c8cfca');
    for (let x = 0; x < 92; x += 23) { rect(g, x, 21, 1, 17, '#606c6b'); rect(g, x + 8, 23, 7, 1, '#454f51'); }
    rect(g, 7, 4, 19, 13, '#424e50'); rect(g, 8, 6, 17, 2, '#7d8c8b'); rect(g, 12, 12, 4, 5, '#fafaf2');
    rect(g, 52, 13, 23, 4, '#c3d0cc'); rect(g, 65, 7, 2, 7, '#afbdb8'); rect(g, 59, 7, 7, 2, '#c7d2cd');
  }, ink);
  return null;
}

export function euroArchitecture(g: Ctx, room: Room): void {
  const kind = room.interior!.reference, W = room.cols * 16, H = room.rows * 16;
  if (kind === 'floor4') {
    // Solid tile footprints remain authoritative. Only the short wall face is projected upward.
    for (let y = 0; y < room.rows - 1; y++) for (let x = 0; x < room.cols; x++) {
      if (tileAt(room, x, y) !== T.WALL || tileAt(room, x, y + 1) === T.WALL) continue;
      rect(g, x * 16, y * 16 - 12, 16, 28, '#d6d9d2'); rect(g, x * 16, y * 16 - 12, 16, 2, '#f0f1eb');
      rect(g, x * 16, y * 16 + 14, 16, 2, '#a6aeaa');
    }
    // The lounge stays behind a closed wall until its separate room is entered.
    glass(g, 240, 316, 16, 40);
    glass(g, 96, 384, 16, 48); rect(g, 107, 401, 3, 5, '#354649');
    glass(g, 256, 384, 16, 16); glass(g, 304, 384, 32, 16);
    rect(g, 272, 383, 32, 2, '#929e9a'); rect(g, 272, 390, 16, 8, '#e6bb4e');
    rect(g, 336, 208, 13, 48, '#b89a43'); rect(g, 338, 210, 11, 42, '#e8cb66'); rect(g, 337, 252, 13, 4, '#d0b354');
    rect(g, 336, 180, 4, 11, '#b84f45'); rect(g, 337, 178, 2, 3, '#59605b');
    // The outer office is visibly continuous with the corridor: no glass/door at its edge.
    for (const x of [24, 88, 152]) {
      rect(g, x, 26, 48, 20, '#cbd8d0');
      for (let y = 27; y < 44; y += 2) rect(g, x + 1, y, 46, 1, '#e4e7df');
    }
    rect(g, 268, 26, 40, 18, '#b3cfcc'); rect(g, 270, 28, 36, 14, '#e0e9e4');
    return;
  }
  // Keep the same cutaway convention as the rest of the game, but use the filmed neutral materials.
  rect(g, 16, 4, W - 32, 42, kind === 'lift' ? '#9aa4a6' : '#e0e1d9');
  if (kind === 'lift') {
    for (let x = 18; x < W - 18; x += 2) rect(g, x, 5, 1, 40, '#8e989b');
    rect(g, 35, 8, 90, 28, '#b8cdcf'); rect(g, 37, 10, 86, 24, '#cedbd9');
    rect(g, 20, 37, W - 40, 2, '#e1e5dd');
    rect(g, 126, 62, 12, 36, '#bbc4c3'); rect(g, 128, 64, 8, 7, '#3c555b');
    for (const y of [77, 85, 93]) { ellipse(g, 132, y, 2, 2, '#e2e5dc'); px(g, 132, y, '#dba74d'); }
  } else if (kind === 'lobby') {
    // Sketch orientation is preserved: recess to the left, glazing to the right.
    rect(g, 128, 48, 16, 128, '#c7ad87'); rect(g, 128, 46, 16, 3, '#ffe4b8');
    rect(g, 0, 256, 144, H - 256, '#c8ac83'); rect(g, 0, 254, 144, 3, '#ffe1ac');
    rect(g, 137, 268, 7, 46, '#46575a'); rect(g, 139, 271, 4, 39, '#a7cec2');
    // Elevator side wall opening and its metal frame.
    rect(g, 0, 76, 18, 4, '#82918e'); rect(g, 0, 112, 18, 4, '#82918e');
    rect(g, 0, 80, 3, 32, '#b8c4be'); rect(g, 20, 83, 3, 7, '#a5aeaa'); px(g, 21, 85, '#e7ba5a');
    glass(g, W - 16, 80, 16, 160);
    // Rear door and restroom door are closed; their unseen rooms are not invented.
    rect(g, 260, 8, 56, 38, '#a5b9b3'); rect(g, 263, 11, 50, 31, '#d1ded6');
    rect(g, 105, 12, 21, 34, '#a6ada4'); rect(g, 108, 15, 15, 28, '#d1d4c8'); px(g, 120, 31, '#647773');
  } else {
    for (const d of room.interior!.decor.filter(d => d.kind === 'window')) {
      rect(g, d.x, 8, d.w, 27, '#8b9b9c'); rect(g, d.x + 1, 9, d.w - 2, 25, '#c6d9d7');
      for (let y = 9; y < 29; y += 2) rect(g, d.x + 1, y, d.w - 2, 1, '#e4e7df');
      rect(g, d.x, 34, d.w, 2, '#a6b2ae');
    }
  }
  if (kind === 'lounge') {
    rect(g, 20, 8, 190, 5, '#5d5a53');
    for (const x of [35, 75, 115, 155, 195]) { rect(g, x, 13, 2, 10, '#5d5a53'); rect(g, x - 2, 23, 6, 3, '#ead9b0'); }
    for (const p of room.interior!.pendants) { rect(g, p.x, p.y - 30, 1, 22, '#514f48'); ellipse(g, p.x, p.y - 5, 4, 4, '#f5e5bc'); }
  }
  rect(g, 16, 46, W - 32, 2, '#9aa7a1');
  // Exit opening is a cut in the wall, never a painted wall on top of a walkable door.
  const [a, b] = room.interior!.door;
  if (a >= 0) { rect(g, a, H - 16, b - a, 16, '#b7bab0'); rect(g, a, H - 16, b - a, 2, '#d9ded4'); }
  for (const r of room.interior!.openings ?? []) { rect(g, r.x, r.y, r.w, r.h, '#aeb1a6'); rect(g, r.x, r.y, r.w, 2, '#e0e2d9'); }
}
function glass(g: Ctx, x: number, y: number, w: number, h: number) {
  rect(g, x, y, w, h, '#9db8b7'); rect(g, x + 2, y + 2, w - 4, h - 4, '#bed0c9');
  rect(g, x + 3, y + 4, w - 6, 2, '#d6aa58'); rect(g, x + 3, y + h - 7, w - 6, 2, '#d6aa58');
  for (let yy = y + 8; yy < y + h - 8; yy += 3) for (let xx = x + 3; xx < x + w - 3; xx += 3) if (hash2(xx, yy, 9) > .5) px(g, xx, yy, '#d5dfd8');
}

/** Fixed warm room lighting, baked once; keeps pixel edges and avoids a per-frame screen filter. */
export function warmLobby(g: Ctx, w: number, h: number): void {
  rect(g, 0, 0, w, h, 'rgba(255,166,64,0.17)');
  for (const x of [64, 176, 288]) {
    ellipse(g, x, 58, 44, 24, 'rgba(255,187,91,0.10)');
    ellipse(g, x, 20, 8, 4, '#d6a45d'); ellipse(g, x, 19, 5, 2, '#ffe6ad');
  }
}
